<?php

define('host', 'localhost');
define('user', 'root');
define('password', '');
define('database', 'epi');

$cnx = mysqli_connect(host, user, password, database);

?>