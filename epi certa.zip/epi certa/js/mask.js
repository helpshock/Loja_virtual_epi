$(document).ready(function(){

    $("#cpf").mask("000.000.000-00");
    $("#rg").mask("00.000.000-0");
    $("#tel").mask("(00) 00000-0000");
    $("#nascimento").mask("00/00/0000");
    $("#cep").mask("00000-000");
})